﻿namespace dSearch.ListItem
{
    public class SearchItem
    {

    }
}