﻿namespace dSearch.ListItem
{
    class SearchItemSmallTitle : SearchItemTile
    {
        public SearchItemSmallTitle(FileInformation file) : base(file)
        {
        }
    }
}
